#ifndef PARSING_H
#define PARSING_H

#include "includes.h"
#include "translator.h"

void parseCommands(Translator *translator);
void parseCommand(Translator *translator);

#endif
