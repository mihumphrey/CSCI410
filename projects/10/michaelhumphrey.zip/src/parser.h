#ifndef PARSER_H
#define PARSER_H

#include "includes.h"
#include "grammar.h"
#include "tokenizer.h"

char *parse(FILE *inputFile);

#endif
